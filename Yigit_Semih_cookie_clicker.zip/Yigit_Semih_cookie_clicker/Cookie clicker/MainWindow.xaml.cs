﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cookie_clicker

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       private double clicks = 0;

        private const int BASIC_PRICE_CURSOR = 15;
        private const int BASIC_PRICE_GRANDMA = 100;
        private const int BASIC_PRICE_FARM = 1100;


        private static System.Timers.Timer cTimer;

        

        public MainWindow()


        {



            InitializeComponent();

            cTimer = new System.Timers.Timer(10);

        }



        private void imgCookie_MouseDown(object sender, MouseButtonEventArgs e)
        {
            clicks++;
            lblClicks.Content = $"{clicks} cookies";
            // imgCookie.ActualWidth = 1.25;
            this.Title = clicks.ToString();
        }

        private void imgCookie_MouseOver() {
          //  imgCookie.Width = 150;


        }


        private void animatiegrootte (double animatie)
        {

        }



    }
}
