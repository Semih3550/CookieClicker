﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Timers;
using System.Threading;
using System.Windows.Threading;

namespace Cookie_clicker
{



    /// <summary>
    /// Interaction logic for WindowUI.xaml
    /// </summary>
    public partial class WindowUI : Window
    {
        private int clicks = 0;

        private const int BASIC_PRICE_CURSOR = 15;
        private const int BASIC_PRICE_GRANDMA = 100;
        private const int BASIC_PRICE_FARM = 1100;

        private double Cursor_clicks = 0;
        private double Cursor_grandma = 0;
        private double Cursor_farm = 0;

        private static System.Timers.Timer cTimer;

        private double tmpPassive;
        private double tmpCookies;


        private int tmpCursorMin;

        public WindowUI()
        {
            InitializeComponent();

            DispatcherTimer cTimer = new DispatcherTimer();
            cTimer.Interval = TimeSpan.FromMilliseconds(10);
            cTimer.Tick += timer_Tick;

            cTimer.Start();

        }

        void timer_Tick(object sender, EventArgs e)
        {



            if (Cursor_clicks > 0)
            {

                tmpPassive += Cursor_clicks * 0.001;

                lblPassiveInc.Content = $"+{tmpPassive.ToString("F")} ";

                tmpCookies = clicks + tmpPassive;

                lblCookieCount.Content = $"{tmpCookies.ToString("F")} Cookies";

                this.Title = tmpCookies.ToString("F");


                btnCursor.ToolTip = $"+{tmpPassive.ToString("F")} ";

            }

            if (Cursor_grandma > 0) {
                tmpPassive += Cursor_clicks * 0.01;

                lblPassiveInc.Content = $"+{tmpPassive.ToString("F")} ";

                tmpCookies = clicks + tmpPassive;

                lblCookieCount.Content = $"{tmpCookies.ToString("F")} Cookies";

                this.Title = tmpCookies.ToString("F");


                btnCursor.ToolTip = $"+{tmpPassive.ToString("F")} ";


            }

            { 
            }
            lblTime.Content = DateTime.Now.ToString("HH:mm:ss.fff");

        }

        private void imgCookie_MouseDown(object sender, MouseButtonEventArgs e)
        {
            clicks++;

            lblCookieCount.Content = $"{clicks} cookies";

            this.Title = clicks.ToString();


            if ((clicks % BASIC_PRICE_CURSOR) == 0)
            {
                Cursor_clicks++;
                btnCursor.IsEnabled = true;
                btnCursor.Content = $"{Cursor_clicks.ToString("G")} Cursor";

            }

            if ((clicks % BASIC_PRICE_GRANDMA) == 0)
            {
                Cursor_grandma++;
                btnGrandma.IsEnabled = true;
                btnGrandma.Content = $"{Cursor_grandma.ToString("F")} Grandma";

            }
            imgCookie.Width = 180;
        }
        private void btnCursor_TooltipOpening(object sender, ToolTipEventArgs e)
        {

            Button b = sender as Button;

            b.ToolTip = $"+{tmpPassive.ToString("F")} ";


        }

        private void btnCursor_Click(object sender, RoutedEventArgs e)
        {



            if (Cursor_clicks > 0)
            {
                tmpCursorMin = tmpCursorMin + 1;

                double basisprijs = BASIC_PRICE_CURSOR * tmpCursorMin;

                lblCursorInvest.Content = $"{basisprijs.ToString("G")} Cursor";

                Cursor_clicks = Cursor_clicks - 1;

                btnCursor.Content = $"{Cursor_clicks.ToString("F")} Cursor";

            }


            if (Cursor_clicks <= 0)
            {
                btnCursor.IsEnabled = false;
            }

        }

        private void imgCookie_MouseUp(object sender, MouseButtonEventArgs e)
        {
            imgCookie.Width = 200;
        }

        private void btnGrandma_Click(object sender, RoutedEventArgs e)
        {
            

            


            
            

        }



    }

}

